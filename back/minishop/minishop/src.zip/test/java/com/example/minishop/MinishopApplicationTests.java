package com.example.minishop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinishopApplicationTests {

	@Test
	void contextLoads() {
	}

}
